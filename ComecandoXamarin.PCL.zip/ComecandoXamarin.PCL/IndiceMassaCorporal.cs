﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ComecandoXamarin.PCL
{
    public class IndiceMassaCorporal
    {
        //menor que 18,5	baixo peso
        //entre 18,5 e 24,9	intervalo normal
        //entre 25 e 29,9	sobrepeso
        //entre 30 e 34,9	obesidade classe I
        //entre 35 e 39,9	obesidade classe II
        //maior que 40	    obesidade classe III
        public static string Calcular(decimal peso, decimal altura)
        {
            string mensagem = string.Empty;

            decimal imc = peso / (altura * altura);

            if (imc < 18.5m)
                mensagem = "Baixo peso";
            else if (imc >= 18.5m && imc < 25m)
                mensagem = "Peso normal";
            else if (imc >= 25m && imc < 30m)
                mensagem = "Sobrepeso";
            else if (imc >= 30m && imc < 35m)
                mensagem = "Obesidade classe I";
            else if (imc >= 35m && imc < 40m)
                mensagem = "Obesidade classe II";
            else
                mensagem = "Obesidade classe III";

            return mensagem;
        }
    }
}
