﻿using ComecandoXamarin.PCL;
using Foundation;
using System;
using UIKit;

namespace ComecandoXamarin.iOS
{
    public partial class MainViewController : UIViewController
    {
        public MainViewController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewDidLoad()
        {
            btnCalcular.TouchUpInside += delegate {
                decimal altura = decimal.Parse(txtAltura.Text);
                decimal peso = decimal.Parse(txtPeso.Text);

                btnCalcular.SetTitle(IndiceMassaCorporal.Calcular(peso, altura).ToString(), UIControlState.Normal);
            };

            base.ViewDidLoad();
        }
    }
}