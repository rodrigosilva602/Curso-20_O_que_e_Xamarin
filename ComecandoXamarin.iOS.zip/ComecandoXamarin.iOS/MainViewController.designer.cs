﻿// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace ComecandoXamarin.iOS
{
    [Register ("MainViewController")]
    partial class MainViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCalcular { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtAltura { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtPeso { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnCalcular != null) {
                btnCalcular.Dispose ();
                btnCalcular = null;
            }

            if (txtAltura != null) {
                txtAltura.Dispose ();
                txtAltura = null;
            }

            if (txtPeso != null) {
                txtPeso.Dispose ();
                txtPeso = null;
            }
        }
    }
}